classdef Polyhedral < dagnn.ElementWise
    properties
        useShortCircuit = true
        leak = 0
        opts = {}
        muCache = [];
        scoreCache = [];
    end
    
    methods
        function outputs = forward(obj, inputs, params)
            %outputs{1} = cat(3, inputs{1}, inputs{1}) ;
        end
        
        function [derInputs, derParams] = backward(obj, inputs, params, derOutputs)
            %derInputs{1} = derOutputs{1}(:,:,1:size(derOutputs{1},3)/2,:) + derOutputs{1}(:,:,size(derOutputs{1},3)/2 + 1:end,:);
            %derParams = {} ;
        end
        
        function forwardAdvanced(obj, layer)
            if ~obj.useShortCircuit || ~obj.net.conserveMemory
                forwardAdvanced@dagnn.Layer(obj, layer) ;
                return ;
            end
            net = obj.net ;
            in = layer.inputIndexes ;
            out = layer.outputIndexes ;
            inputs = net.vars(in);
            scores = gather(inputs(1).value);
            labels = gather(inputs(2).value);
            
            noClasses = size(net.params(end).value, 1);
            featureSize = size(scores,3);
            batchSize = size(scores,4);
            mu = zeros(1, noClasses, featureSize);
            max_labels = max(max(labels));
            
            
            if (noClasses == 1) 
                freq = sum(labels == 1);
                for indImage = 1:batchSize
                    if labels(indImage) == 1
                        mu(1, 1, :) = mu(1, 1, :) + scores(1,1,:,indImage);
                    end
                end
                mu = mu / freq;
                if freq <= 1
                    if ~isempty(obj.muCache)
                        mu(1, 1, :) = obj.muCache(1, 1, :);
                    else
                        mu(1, 1, :) = 0;
                    end
                end
                
                if freq >= 2
                    obj.muCache = mu;
                end
                
                file_name=['/home/mlcv/Desktop/ResNet-Matconvnet/polyhedral_mean/meansbc.mat'];
                save(file_name,'mu');
                
                output = zeros(1, 1, featureSize * 2, batchSize);
                for indImage = 1:batchSize
                        output(1, 1, :, indImage) = cat(3, scores(1, 1, :, indImage) - mu(1, 1, :), abs(scores(1, 1, :, indImage) - mu(1, 1, :)));
                end
                
                % multiclass
            elseif (noClasses >=2 & max_labels>1)
                
                for indImage = 1:batchSize
                    mu(1, labels(indImage), :) = mu(1, labels(indImage), :) + scores(1,1,:,indImage);
                end
                
                freqs = zeros(noClasses,1);
                for indClass = 1:noClasses
                    freqs(indClass) = sum(sum(labels == indClass));
                    mu(1, indClass, :) = mu(1, indClass, :) / freqs(indClass);
                    if freqs(indClass) <= 1 
                        if ~isempty(obj.muCache)
                            mu(1, indClass, :) = obj.muCache(1, indClass, :);
                        else
                            mu(1, indClass, :) = 0;
                        end
                    end
                end
                
                if isempty(obj.muCache)
                    obj.muCache = single(zeros(size(mu)));
                end
                
                for indClass = 1:noClasses
                    if freqs(indClass) >= 2
                        obj.muCache(1, indClass, :) = mu(1, indClass, :);
                    end
                end
                
                output = zeros(1, 1, featureSize * 2, batchSize);
                
              file_name=['/home/mlcv/Desktop/ResNet-Matconvnet/polyhedral_mean/meansmc.mat'];
              save(file_name,'mu');
              %load(file_name);
                
                for indImage = 1:batchSize
                    output(1, 1, :, indImage) = cat(3, scores(1, 1, :, indImage) - mu(1, labels(indImage), :), abs(scores(1, 1, :, indImage) - mu(1, labels(indImage), :)));
                end
                
           % multi label classification
            else
                %label_matrix
                freqs = zeros(noClasses,1);
                for ii=1:noClasses,
                    mu_indices=find(label_matrix(:,ii)==1;
                    freqs(ii)=length(mu_indices);
                    mu(1, ii, :) = mean(scores(1,1,:,mu_indices));
                    if freqs(indClass) <= 1 
                        if ~isempty(obj.muCache)
                            mu(1, indClass, :) = obj.muCache(1, indClass, :);
                        else
                            mu(1, indClass, :) = 0;
                        end
                    end
                end
                                
                if isempty(obj.muCache)
                    obj.muCache = single(zeros(size(mu)));
                end
                
                for indClass = 1:noClasses
                    if freqs(indClass) >= 2
                        obj.muCache(1, indClass, :) = mu(1, indClass, :);
                    end
                end
                
                output = zeros(1, 1, featureSize * 2, batchSize);
                
              file_name=['/home/mlcv/Desktop/ResNet-Matconvnet/polyhedral_mean/meansml.mat'];
              save(file_name,'mu');
              %load(file_name);
                
                for indImage = 1:batchSize
                    ll=find(label_matrix(indImage,:)==1);
                    mu_sample = mean(mu(1, ll, :));
                    output(1, 1, :, indImage) = cat(3, scores(1, 1, :, indImage) - mu_sample, abs(scores(1, 1, :, indImage) - mu_sample));
                end
                
            end
            
            obj.scoreCache = output;
            
            net.vars(out).value = gpuArray(single(output));
            
            for v = in
                net.numPendingVarRefs(v) = net.numPendingVarRefs(v) - 1;
                if ~net.vars(v).precious & net.numPendingVarRefs(v) == 0
                    net.vars(v).value = [] ;
                end
            end
        end
        
        function backwardAdvanced(obj, layer)
            if ~obj.useShortCircuit || ~obj.net.conserveMemory
                backwardAdvanced@dagnn.Layer(obj, layer) ;
                return ;
            end
            net = obj.net ;
            in = layer.inputIndexes ;
            out = layer.outputIndexes ;
            
            if isempty(net.vars(out).der), return ; end
            
            derInput = net.vars(out).der(:,:,1:size(net.vars(out).der,3)/2,:) + sign(obj.scoreCache(:, :, size(obj.scoreCache, 3)/2+1:end, :)) .* net.vars(out).der(:,:,size(net.vars(out).der,3)/2+1:end,:);
            
            if ~net.vars(out).precious
                net.vars(out).der = [] ;
                net.vars(out).value = [] ;
            end
            
            if net.numPendingVarRefs(in(1)) == 0
                net.vars(in(1)).der = derInput ;
            else
                net.vars(in(1)).der = net.vars(in(1)).der + derInput ;
            end
            net.numPendingVarRefs(in(1)) = net.numPendingVarRefs(in(1)) + 1 ;
            
            net.vars(in(2)).der = [];
            %net.numPendingVarRefs(in(2)) = net.numPendingVarRefs(in(2)) + 1 ;
        end
        
        function obj = Polyhedral(varargin)
            obj.load(varargin) ;
        end
    end
end
